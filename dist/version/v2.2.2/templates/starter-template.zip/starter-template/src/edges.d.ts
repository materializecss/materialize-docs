export declare class Edges {
    top: boolean;
    right: boolean;
    bottom: boolean;
    left: boolean;
}
//# sourceMappingURL=edges.d.ts.map